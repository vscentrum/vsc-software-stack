wget http://bioinf.uni-greifswald.de/bioinf/braker/RNAseq.bam
